import { connect } from "react-redux";
import Main from "./Main.jsx";

const mapStateToProps = ({

}) => ({

});

const mapDispatchToProps = () => dispatch => ({

});

export default connect(mapStateToProps, mapDispatchToProps)(Main);
